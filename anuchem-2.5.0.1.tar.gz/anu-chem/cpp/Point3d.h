#ifndef __POINT_3D_H
#define __POINT_3D_H

struct Point3d {
	double i;
	double j;
	double k;
};

#endif // POINT_3D_H
