struct Point3d {

}
