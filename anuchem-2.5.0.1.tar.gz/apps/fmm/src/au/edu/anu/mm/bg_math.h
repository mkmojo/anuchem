#ifdef __BG__
#include "mass.h"
#endif
