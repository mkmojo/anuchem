echo "mpiexec -n $X10_NPLACES -x X10_NTHREADS=1 bin/pme test/gromacs/box100k.gro 0.35 10.0 96"
mpiexec -n $X10_NPLACES -x X10_NTHREADS=1 bin/pme test/gromacs/box100k.gro 0.35 10.0 96
mpiexec -n $X10_NPLACES -x X10_NTHREADS=1 bin/pme test/gromacs/box100k.gro 0.35 10.0 96
mpiexec -n $X10_NPLACES -x X10_NTHREADS=1 bin/pme test/gromacs/box100k.gro 0.35 10.0 96

