X10_NTHREADS=1 bin/pme test/gromacs/box12k.gro 0.35 10.0 42
X10_NTHREADS=1 bin/pme test/gromacs/box27k.gro 0.35 10.0 56
X10_NTHREADS=1 bin/pme test/gromacs/box51k.gro 0.35 10.0 72
X10_NTHREADS=1 bin/pme test/gromacs/box100k.gro 0.35 10.0 96
X10_NTHREADS=1 bin/pme test/gromacs/box194k.gro 0.35 10.0 108
X10_NTHREADS=1 bin/pme test/gromacs/box497k.gro 0.35 10.0 144
X10_NTHREADS=1 bin/pme test/gromacs/box1067k.gro 0.35 10.0 192

