#include <fftw3.h>

namespace edu {
    namespace mit {
        namespace fftw {
            typedef fftw_plan FFTW_FFTWPlan;
        }
    }
}

